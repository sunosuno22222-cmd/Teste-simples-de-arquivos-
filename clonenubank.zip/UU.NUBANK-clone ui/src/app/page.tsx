"use client";

import { useState, useEffect } from 'react';
import LoginPage from '@/components/pages/login-page';
import DashboardPage from '@/components/pages/dashboard-page';
import { Skeleton } from '@/components/ui/skeleton';
import { useUser, useAuth, useFirebase, setDocumentNonBlocking } from '@/firebase';
import { initiateAnonymousSignIn } from '@/firebase/non-blocking-login';
import { doc } from 'firebase/firestore';


export interface UserProfile {
  name: string;
  cpf: string;
}

export default function Home() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const { firestore } = useFirebase();

  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // This effect handles the initial user state and local storage logic
    if (!isUserLoading) {
      if (user) {
        const storedProfile = localStorage.getItem('roxoCloneUserProfile');
        if (storedProfile) {
          setUserProfile(JSON.parse(storedProfile));
        }
      } else {
        // No Firebase user, clear local user profile
        localStorage.removeItem('roxoCloneUserProfile');
        setUserProfile(null);
      }
      setIsLoading(false);
    }
  }, [user, isUserLoading]);

  const handleLogin = async ({ name, cpf }: UserProfile) => {
    try {
      const profile = { name, cpf };
      localStorage.setItem('roxoCloneUserProfile', JSON.stringify(profile));
      setUserProfile(profile);

      if (!auth.currentUser && firestore) {
        await initiateAnonymousSignIn(auth);
        // We need to wait for the user to be available after sign-in
        // A better approach is to listen to auth state changes, but for this flow let's add a small delay
        // This is not ideal but will work for this specific case.
         setTimeout(() => {
            if (auth.currentUser) {
                const userRef = doc(firestore, "users", auth.currentUser.uid);
                setDocumentNonBlocking(userRef, {
                    id: auth.currentUser.uid,
                    name: profile.name,
                    cpf: profile.cpf,
                }, { merge: true });
            }
        }, 1500); // wait 1.5s for auth state to propagate
      } else if (auth.currentUser && firestore) {
           const userRef = doc(firestore, "users", auth.currentUser.uid);
           setDocumentNonBlocking(userRef, {
              id: auth.currentUser.uid,
              name: profile.name,
              cpf: profile.cpf,
           }, { merge: true });
      }

    } catch (error) {
      console.error("Could not access local storage or save user data:", error);
    }
  };


  const handleLogout = async () => {
    try {
      if (auth) {
         await auth.signOut();
      }
      // This is already handled by the useEffect
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  if (isLoading || isUserLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-background p-8">
        <div className="w-full max-w-sm space-y-4">
            <Skeleton className="h-10 w-1/3" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full mt-4" />
        </div>
      </div>
    );
  }

  return (
    <main>
      {user && userProfile ? (
        <DashboardPage userProfile={userProfile} onLogout={handleLogout} />
      ) : (
        <LoginPage onLogin={handleLogin} />
      )}
    </main>
  );
}
