"use client";
import React from 'react';
import { ChevronRight } from 'lucide-react';
import { Input } from '../ui/input';

interface AccountBalanceProps {
  isVisible: boolean;
  balance: number;
  onBalanceChange: (balance: number) => void;
}

export default function AccountBalance({ isVisible, balance, onBalanceChange }: AccountBalanceProps) {
    const formatCurrencyForInput = (value: number) => {
        const options = {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        };
        return (value / 100).toLocaleString('pt-BR', options);
    };

    const handleBalanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        const numericValue = value.replace(/\D/g, '');
        if (numericValue) {
            const intValue = parseInt(numericValue, 10);
            onBalanceChange(intValue);
        } else {
            onBalanceChange(0);
        }
    };

    return (
        <div className="cursor-pointer px-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-medium text-foreground">Conta</h2>
                <ChevronRight className="h-6 w-6 text-muted-foreground" />
            </div>
            <div className="mt-2">
                {isVisible ? (
                    <div className="flex items-center">
                        <span className="text-2xl font-medium text-foreground mr-1">R$</span>
                        <Input
                            type="text"
                            value={formatCurrencyForInput(balance)}
                            onChange={handleBalanceChange}
                            className="bg-transparent text-2xl font-medium border-0 text-foreground focus-visible:ring-0 focus-visible:ring-offset-0 p-0 h-auto"
                        />
                    </div>
                ) : (
                    <div className="h-8 w-36 bg-muted rounded-sm" />
                )}
            </div>
        </div>
    );
}
