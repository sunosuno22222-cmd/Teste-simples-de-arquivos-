"use client";

import React, { useState } from 'react';
import PixFlow from '../pix/pix-flow';
import { UserProfile } from '@/app/page';

const PixIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M15.42 8.52632L12 5L8.58 8.52632H11.11V10.8421H8.58L12 14.3684L15.42 10.8421H12.89V8.52632H15.42Z" stroke="#111827" strokeWidth="1.5" strokeLinejoin="round"></path>
        <path d="M12 11.7105C11.0836 11.7105 10.33 12.4641 10.33 13.3805C10.33 14.2969 11.0836 15.0505 12 15.0505C12.9164 15.0505 13.67 14.2969 13.67 13.3805C13.67 12.4641 12.9164 11.7105 12 11.7105Z" stroke="#111827" strokeWidth="1.5"></path>
        <path d="M13.46 17.5L16.5 14.46H14.25L13.46 15.25V17.5Z" stroke="#111827" strokeWidth="1.5" strokeLinejoin="round"></path>
        <path d="M10.54 17.5L7.5 14.46H9.75L10.54 15.25V17.5Z" stroke="#111827" strokeWidth="1.5" strokeLinejoin="round"></path>
    </svg>
);

const PagarIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M3 7H21M3 12H21M3 17H15" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

const TransferirIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M16 4L19 7L16 10" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M19 7H5" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M8 20L5 17L8 14" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 17H19" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

const DepositarIcon = (props: React.SVGProps<SVGSVGElement>) => (
     <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M16 17L19 14L16 11" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M19 14H5" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M8 7L5 10L8 13" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 10H19" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

const EmprestimoIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 10.74 21.78 9.55 21.38 8.44" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M15.5 8.5C14.8284 8.5 14.25 7.92157 14.25 7.25C14.25 6.57843 14.8284 6 15.5 6C16.1716 6 16.75 6.57843 16.75 7.25C16.75 7.92157 16.1716 8.5 15.5 8.5Z" fill="#111827"/>
        <path d="M8.5 15.5C7.82843 15.5 7.25 14.9216 7.25 14.25C7.25 13.5784 7.82843 13 8.5 13C9.17157 13 9.75 13.5784 9.75 14.25C9.75 14.9216 9.17157 15.5 8.5 15.5Z" fill="#111827"/>
        <path d="M8 12L16 8" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);


const actionItems = [
    { icon: PixIcon, label: 'Pix', isPix: true },
    { icon: PagarIcon, label: 'Pagar' },
    { icon: TransferirIcon, label: 'Transferir' },
    { icon: DepositarIcon, label: 'Depositar' },
    { icon: EmprestimoIcon, label: 'Pegar emprestado' },
];

interface ActionShortcutsProps {
    userProfile: UserProfile;
}

export default function ActionShortcuts({ userProfile }: ActionShortcutsProps) {
    const [isPixFlowOpen, setIsPixFlowOpen] = useState(false);
    return (
        <>
            <div className="overflow-x-auto pt-5 pb-3 -mx-6 px-6 no-scrollbar">
                <div className="flex space-x-4">
                    {actionItems.map((item, index) => (
                        <div key={index} onClick={item.isPix ? () => setIsPixFlowOpen(true) : undefined} className="flex flex-col items-center justify-start space-y-2 cursor-pointer w-[80px] text-center flex-shrink-0">
                            <div className="h-16 w-16 bg-muted rounded-full flex items-center justify-center">
                                <item.icon className="h-6 w-6 text-foreground" />
                            </div>
                            <span className="text-sm font-medium leading-tight pt-1 text-foreground">{item.label}</span>
                        </div>
                    ))}
                </div>
                <style jsx>{`
                    .no-scrollbar::-webkit-scrollbar {
                        display: none;
                    }
                    .no-scrollbar {
                        -ms-overflow-style: none;
                        scrollbar-width: none;
                    }
                `}</style>
            </div>
            <PixFlow isOpen={isPixFlowOpen} onOpenChange={setIsPixFlowOpen} userProfile={userProfile} />
        </>
    );
}
