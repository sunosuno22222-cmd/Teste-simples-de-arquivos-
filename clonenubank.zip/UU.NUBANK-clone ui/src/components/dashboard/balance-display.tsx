"use client";
import React from 'react';

interface BalanceDisplayProps {
    amount: number;
    isVisible: boolean;
}

export default function BalanceDisplay({ amount, isVisible }: BalanceDisplayProps) {
    const [isLoaded, setIsLoaded] = React.useState(false);

    React.useEffect(() => {
        const timer = setTimeout(() => setIsLoaded(true), 300);
        return () => clearTimeout(timer);
    }, []);

    const formatCurrency = (value: number) => {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    return (
        <div className={`transition-opacity duration-500 mt-2 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
            {isVisible ? (
               <p className="text-2xl font-medium text-foreground">{formatCurrency(amount)}</p>
            ) : (
               <div className="h-7 w-36 bg-muted rounded-sm" />
            )}
        </div>
    );
}
