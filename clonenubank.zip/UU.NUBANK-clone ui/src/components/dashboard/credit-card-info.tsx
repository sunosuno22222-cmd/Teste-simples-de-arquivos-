"use client";
import React from 'react';
import { ChevronRight } from 'lucide-react';
import BalanceDisplay from './balance-display';

interface CreditCardInfoProps {
  isVisible: boolean;
}

const CartaoCreditoIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M21 5H3C2.44772 5 2 5.44772 2 6V18C2 18.5523 2.44772 19 3 19H21C21.5523 19 22 18.5523 22 18V6C22 5.44772 21.5523 5 21 5Z" stroke="#111827" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M2 10H22" stroke="#111827" strokeWidth="2"/>
    </svg>
);


export default function CreditCardInfo({ isVisible }: CreditCardInfoProps) {

  return (
    <div className="cursor-pointer border-t border-border pt-5 px-6 space-y-3">
       <div className="flex justify-between items-center">
        <h2 className="text-xl font-medium text-foreground">Cartão de crédito</h2>
        <ChevronRight className="h-6 w-6 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground font-medium">Fatura atual</p>
      <BalanceDisplay amount={1250.50} isVisible={isVisible}/>
      <p className="text-sm text-muted-foreground font-medium">Limite disponível de R$ 4.780,00</p>
    </div>
  );
}
