export default function DisclaimerBanner() {
    return (
        <footer className="fixed bottom-0 left-0 right-0 w-full max-w-lg mx-auto flex-shrink-0">
            <div className="bg-secondary/90 backdrop-blur-sm p-3 text-center text-xs text-secondary-foreground z-10">
                <p>Aviso: Este app é apenas uma simulação educativa. Para serviços financeiros reais, utilize o aplicativo oficial Nubank.</p>
            </div>
        </footer>
    );
}
