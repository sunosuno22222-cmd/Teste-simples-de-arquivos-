"use client";

import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { PixFormData } from '../pix/pix-form-schema';

interface TransactionItemProps {
    transaction: PixFormData;
}

const TransferSentIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M21 5H3C2.44772 5 2 5.44772 2 6V18C2 18.5523 2.44772 19 3 19H21C21.5523 19 22 18.5523 22 18V6C22 5.44772 21.5523 5 21 5Z" stroke="#111827" strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M17 14L20 11.5L17 9" stroke="#111827" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);


export default function TransactionItem({ transaction }: TransactionItemProps) {

    const formatCurrency = (value: number) => {
        return (value/100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    const formatDate = (date: Date) => {
        return format(date, "dd MMM", { locale: ptBR }).toUpperCase();
    }

    return (
        <div className="flex items-start space-x-4 py-3">
            <div className="bg-muted h-10 w-10 rounded-full flex items-center justify-center">
                <TransferSentIcon className="h-6 w-6" />
            </div>
            <div className="flex-1">
                <div className="flex justify-between items-baseline">
                    <p className="font-medium">Transferência enviada</p>
                    <p className="text-xs text-muted-foreground">{formatDate(transaction.date)}</p>
                </div>
                <p className="text-sm text-muted-foreground">{transaction.receiverName}</p>
                <p className="font-medium mt-1">{formatCurrency(transaction.amount)}</p>
                <p className="text-sm text-muted-foreground">{transaction.transferType}</p>
            </div>
        </div>
    );
}
