"use client";

import React from 'react';
import Header from '@/components/dashboard/header';
import AccountBalance from '@/components/dashboard/account-balance';
import ActionShortcuts from '@/components/dashboard/action-shortcuts';
import CreditCardInfo from '@/components/dashboard/credit-card-info';
import DisclaimerBanner from '@/components/dashboard/disclaimer-banner';
import { Button } from '../ui/button';
import { Card, CardContent } from "@/components/ui/card";
import { UserProfile } from '@/app/page';
import HistoryPage from './history-page';

interface DashboardPageProps {
  userProfile: UserProfile;
  onLogout: () => void;
}

const CartaoIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M21 5H3C2.44772 5 2 5.44772 2 6V18C2 18.5523 2.44772 19 3 19H21C21.5523 19 22 18.5523 22 18V6C22 5.44772 21.5523 5 21 5Z" stroke="#111827" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M2 10H22" stroke="#111827" strokeWidth="2"/>
    </svg>
);


export default function DashboardPage({ userProfile, onLogout }: DashboardPageProps) {
    const [isBalanceVisible, setIsBalanceVisible] = React.useState(true);
    const [balance, setBalance] = React.useState(123456); // Example balance in cents
    const [showHistory, setShowHistory] = React.useState(false);
    
    if (showHistory) {
        return <HistoryPage onBack={() => setShowHistory(false)} userProfile={userProfile} />;
    }

    return (
        <div className="h-screen w-screen bg-background text-foreground flex flex-col max-w-lg mx-auto font-body">
            <Header
                userName={userProfile.name}
                isBalanceVisible={isBalanceVisible}
                toggleBalanceVisibility={() => setIsBalanceVisible(!isBalanceVisible)}
            />

            <main className="flex-1 pt-6 space-y-5 overflow-y-auto pb-20">
                <div onClick={() => setShowHistory(true)}>
                    <AccountBalance 
                      isVisible={isBalanceVisible}
                      balance={balance}
                      onBalanceChange={setBalance}
                    />
                </div>
                
                <ActionShortcuts userProfile={userProfile} />
                
                <div className="px-6">
                    <Button variant="secondary" className="w-full justify-start h-14 text-sm font-medium bg-muted rounded-xl">
                        <CartaoIcon className="mr-3 h-6 w-6"/>
                        Meus cartões
                    </Button>
                </div>

                <div className="px-6 flex space-x-3 overflow-x-auto no-scrollbar">
                    <Card className="flex-none bg-muted p-4 cursor-pointer hover:bg-border transition-colors rounded-xl min-w-[250px]">
                        <CardContent className="p-0">
                            <p className="text-sm text-foreground whitespace-normal leading-snug">Gostando do aplicativo? <br/><span className="text-primary">Avalie na Play Store</span></p>
                        </CardContent>
                    </Card>
                    <Card className="flex-none bg-muted p-4 cursor-pointer hover:bg-border transition-colors rounded-xl min-w-[250px]">
                         <CardContent className="p-0">
                           <p className="text-sm text-foreground whitespace-normal leading-snug">Convide seus amigos para o Nubank e <span className="text-primary">desbloqueie brasões</span></p>
                        </CardContent>
                    </Card>
                </div>
                
                <CreditCardInfo isVisible={isBalanceVisible} />
                <div className='px-6'>
                    <Button onClick={onLogout} variant="destructive" className="w-full">Sair</Button>
                </div>

            </main>
            <DisclaimerBanner />
             <style jsx>{`
                .no-scrollbar::-webkit-scrollbar {
                    display: none;
                }
                .no-scrollbar {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
            `}</style>
        </div>
    );
}
