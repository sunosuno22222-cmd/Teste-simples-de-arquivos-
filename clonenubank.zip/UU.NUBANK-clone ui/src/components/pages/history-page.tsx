"use client";

import React, { useState, useEffect } from 'react';
import { ArrowLeft, HelpCircle, Plus } from 'lucide-react';
import PixFlow from '../pix/pix-flow';
import TransactionItem from '../history/transaction-item';
import { PixFormData } from '../pix/pix-form-schema';
import { UserProfile } from '@/app/page';
import { useUser, useFirebase } from '@/firebase';
import { collection, onSnapshot, query, orderBy, addDoc } from 'firebase/firestore';

interface HistoryPageProps {
    onBack: () => void;
    userProfile: UserProfile;
}

const EmprestimoIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 10.74 21.78 9.55 21.38 8.44" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M15.5 8.5C14.8284 8.5 14.25 7.92157 14.25 7.25C14.25 6.57843 14.8284 6 15.5 6C16.1716 6 16.75 6.57843 16.75 7.25C16.75 7.92157 16.1716 8.5 15.5 8.5Z" fill="#111827"/>
        <path d="M8.5 15.5C7.82843 15.5 7.25 14.9216 7.25 14.25C7.25 13.5784 7.82843 13 8.5 13C9.17157 13 9.75 13.5784 9.75 14.25C9.75 14.9216 9.17157 15.5 8.5 15.5Z" fill="#111827"/>
        <path d="M8 12L16 8" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);


export default function HistoryPage({ onBack, userProfile }: HistoryPageProps) {
    const [isPixFlowOpen, setIsPixFlowOpen] = useState(false);
    const [transactions, setTransactions] = useState<PixFormData[]>([]);
    const { user } = useUser();
    const { firestore } = useFirebase();
    
    useEffect(() => {
        if (!user || !firestore) return;

        const transactionsRef = collection(firestore, 'users', user.uid, 'transactionReceipts');
        const q = query(transactionsRef, orderBy('date', 'desc'));

        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const receipts = querySnapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    ...data,
                    date: data.date.toDate(),
                } as PixFormData;
            });
            setTransactions(receipts);
        });

        return () => unsubscribe();
    }, [user, firestore]);

    const handleAddTransaction = async (newTransaction: PixFormData) => {
        if (!user || !firestore) {
            console.error("User not authenticated or firestore not available");
            return;
        }

        try {
            const transactionsRef = collection(firestore, 'users', user.uid, 'transactionReceipts');
            await addDoc(transactionsRef, newTransaction);
        } catch (error) {
            console.error("Error adding transaction to Firestore:", error);
        }

        setIsPixFlowOpen(false);
    };

    return (
        <>
            <div className="flex h-screen flex-col bg-background text-foreground max-w-lg mx-auto font-body">
                <header className="flex items-center justify-between p-4">
                    <button onClick={onBack} aria-label="Voltar">
                        <ArrowLeft className="h-6 w-6" />
                    </button>
                    <div className="flex items-center space-x-4">
                        <button onClick={() => setIsPixFlowOpen(true)} aria-label="Adicionar transação">
                           <Plus className="h-6 w-6 text-primary" />
                        </button>
                        <button aria-label="Ajuda">
                            <HelpCircle className="h-6 w-6" />
                        </button>
                    </div>
                </header>

                <main className="flex-1 overflow-y-auto px-4 space-y-4">
                    <div className="bg-muted p-4 rounded-lg flex items-center justify-between cursor-pointer">
                        <div className="flex items-center space-x-3">
                            <EmprestimoIcon className="h-6 w-6 text-foreground" />
                            <div>
                                <p className="font-medium">disponível para empréstimo</p>
                            </div>
                        </div>
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 1L7 7L1 13" stroke="#A1A1AA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </div>

                    <h1 className="text-xl font-medium">Histórico</h1>

                    <div className="space-y-4">
                         {transactions.length > 0 ? (
                            transactions.map((transaction, index) => (
                                <TransactionItem key={index} transaction={transaction} />
                            ))
                        ) : (
                             <div className="text-center py-10">
                                <p className="text-muted-foreground">Nenhuma transação ainda.</p>
                                <p className="text-muted-foreground">Clique em '+' para adicionar uma.</p>
                            </div>
                        )}
                    </div>
                </main>
            </div>
            <PixFlow 
                isOpen={isPixFlowOpen} 
                onOpenChange={setIsPixFlowOpen} 
                userProfile={userProfile} 
                onTransactionComplete={handleAddTransaction}
            />
        </>
    );
}
