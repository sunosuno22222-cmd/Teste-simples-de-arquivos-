"use client";

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from '../ui/label';
import { ArrowLeft } from 'lucide-react';
import { UserProfile } from '@/app/page';

interface LoginPageProps {
  onLogin: (profile: UserProfile) => void;
}

const NubankLogo = () => (
    <svg height="28" viewBox="0 0 24 24" className="w-auto h-7 text-white">
        <path fill="currentColor" d="M21.573 8.356c-2.31-2.06-5.405-3.356-8.83-3.356-6.627 0-12 5.373-12 12 0 1.954.468 3.8.1287 5.48h21.426c.996-1.583 1.573-3.418 1.573-5.356.001-3.23-1.228-6.19-3.256-8.268zm-9.573 9.644v-4h-4v4h4zm4 0v-4h-2v4h2zm2 0v-4h2v4h-2zM12 7c2.206 0 4 1.794 4 4s-1.794 4-4 4-4-1.794-4-4 1.794-4 4-4z" />
    </svg>
);


export default function LoginPage({ onLogin }: LoginPageProps) {
  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');
  const [step, setStep] = useState(1);

  const handleCpfSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cpf.replace(/\D/g, '').length === 11) {
      setStep(3);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && cpf.trim()) {
      onLogin({ name: name.trim(), cpf: cpf.trim() });
    }
  }

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numericValue = value.replace(/\D/g, '');
    let formattedValue = numericValue;
    if (numericValue.length > 3) {
      formattedValue = numericValue.replace(/(\d{3})(\d)/, '$1.$2');
    }
    if (numericValue.length > 6) {
      formattedValue = formattedValue.replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
    }
    if (numericValue.length > 9) {
      formattedValue = formattedValue.replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4');
    }
    setCpf(formattedValue.substring(0, 14));
  };


  return (
    <div className="flex h-screen w-screen flex-col bg-primary p-6 text-primary-foreground">
        <div className="flex-1 flex flex-col justify-between">
            {step === 1 && (
                <>
                    <div>
                        <button aria-label="Logo Nubank" className='mb-8'>
                           <NubankLogo />
                        </button>
                        <h1 className="text-2xl font-medium mt-8 leading-tight">Um mundo financeiro sem complexidades</h1>
                    </div>
                    <div className="w-full">
                       <Button onClick={() => setStep(2)} className="w-full bg-primary-foreground text-primary h-14 text-lg font-semibold">Começar</Button>
                    </div>
                </>
            )}

            {step === 2 && (
                 <>
                    <div>
                        <button onClick={() => setStep(1)} className='mb-8'>
                            <ArrowLeft className="h-6 w-6" />
                        </button>
                        <h1 className="text-2xl font-medium mt-4 leading-tight">Qual é o seu CPF?</h1>
                         <p className="text-primary-foreground/70 mt-2">Precisamos do seu CPF para começar.</p>
                    </div>
                    <form onSubmit={handleCpfSubmit} className="space-y-4">
                       <div>
                            <Label htmlFor="cpf-input">CPF</Label>
                             <Input
                                id="cpf-input"
                                type="text"
                                value={cpf}
                                onChange={handleCpfChange}
                                required
                                className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14"
                                aria-label="CPF"
                                autoFocus
                                placeholder="000.000.000-00"
                            />
                       </div>
                        <Button type="submit" className="w-full bg-primary-foreground text-primary h-14 text-lg font-semibold" disabled={cpf.replace(/\D/g, '').length !== 11}>
                            Continuar
                        </Button>
                    </form>
                </>
            )}

             {step === 3 && (
                 <>
                    <div>
                        <button onClick={() => setStep(2)} className='mb-8'>
                            <ArrowLeft className="h-6 w-6" />
                        </button>
                        <h1 className="text-2xl font-medium mt-4 leading-tight">E o seu nome completo?</h1>
                    </div>
                    <form onSubmit={handleLoginSubmit} className="space-y-4">
                       <div>
                            <Label htmlFor="name-input">Nome Completo</Label>
                             <Input
                                id="name-input"
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14"
                                aria-label="Nome Completo"
                                autoFocus
                            />
                       </div>
                        <Button type="submit" className="w-full bg-primary-foreground text-primary h-14 text-lg font-semibold" disabled={!name.trim()}>
                            Finalizar cadastro
                        </Button>
                    </form>
                </>
            )}
        </div>
    </div>
  );
}
