"use client";

import { useRef } from 'react';
import html2canvas from 'html2canvas';
import { Button } from '../ui/button';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { v4 as uuidv4 } from 'uuid';
import { PixFormData } from '../pix/pix-form-schema';
import { useToast } from '@/hooks/use-toast';
import { Download } from 'lucide-react';

interface ReceiptPageProps {
  formData: PixFormData;
  onDone: () => void;
}

const NubankLogo = () => (
    <svg width="48" height="28" viewBox="0 0 48 28" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M24.8913 2.18829C24.5833 2.18829 24.2829 2.21396 23.9824 2.26529C23.2201 2.39329 22.4961 2.65063 21.8481 2.99929C21.1925 3.34796 20.6128 3.78796 20.1091 4.29863L19.9888 4.41863L18.8091 5.60596L19.7891 7.02529L19.9554 7.28396L21.3748 7.28396L21.7348 7.07863C21.9474 6.94263 22.1858 6.78863 22.4498 6.61663C23.1661 6.16396 23.9938 5.86396 24.8913 5.86396C25.431 5.86396 25.963 5.95529 26.477 6.13663C27.0068 6.32596 27.4981 6.59863 27.9354 6.94263L28.1894 7.14796L28.5958 7.32929H36.8185L36.8185 2.18829H24.8913ZM24.8915 28C17.9308 28 12.0628 24.7137 8.3075 19.3497L11.5938 19.3497C11.5938 19.3497 11.5938 19.3497 11.5938 19.3497L11.5938 8.96638L4.65483 8.96638C4.1975 11.977 3.6935 15.1164 3.16383 18.3377C2.9745 19.4764 2.8385 20.6404 2.74717 21.821L0 21.821L0 28L2.06283 28C2.52017 25.1164 3.0165 22.1464 3.49917 19.1124L3.88483 16.711L4.60883 12.6444L8.33317 12.6444L8.33317 24.7137L4.60883 24.7137C5.55517 26.0484 6.75517 27.187 8.16917 28H24.8915ZM48 2.18829L48 0L39.3838 0L39.3838 7.32929L48 7.32929L48 2.18829Z" fill="#820AD1"/>
    </svg>
);


const ReceiptField = ({ label, value }: { label: string; value: string | undefined }) => (
    value ? (
        <div className="flex justify-between items-start">
            <p className="text-sm text-gray-500">{label}</p>
            <p className="text-sm text-gray-900 font-medium text-right break-words max-w-[60%]">{value}</p>
        </div>
    ) : null
);

const SectionTitle = ({ icon: Icon, title }: { icon: React.ElementType, title: string }) => (
    <div className="flex items-center space-x-2 text-gray-600">
        <Icon size={20} />
        <h2 className="font-medium text-lg">{title}</h2>
    </div>
);


export default function ReceiptPage({ formData, onDone }: ReceiptPageProps) {
  const receiptRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const transactionId = `E${uuidv4().replace(/-/g, '').toUpperCase()}`;

  const formatCurrency = (value: number) => {
    return (value/100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };
  
  const handleDownload = async () => {
    if (!receiptRef.current) {
      toast({
        variant: "destructive",
        title: "Erro ao gerar comprovante",
        description: "Não foi possível encontrar a referência do comprovante.",
      });
      return;
    }
    
    try {
      const canvas = await html2canvas(receiptRef.current, { 
        backgroundColor: null, // Use transparent background
        scale: 2 // Increase resolution
      });
      const imageDataUrl = canvas.toDataURL('image/png');
      
      const link = document.createElement('a');
      link.href = imageDataUrl;
      link.download = `comprovante-transferencia-${uuidv4()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Download Iniciado",
        description: "Seu comprovante está sendo baixado.",
      });

    } catch (error: any) {
      console.error("Error generating receipt image:", error);
      toast({
        variant: "destructive",
        title: "Erro ao gerar imagem",
        description: error.message || "Ocorreu um erro ao gerar a imagem do comprovante.",
      });
    }
  };

  const maskCpf = (cpf: string) => {
    if (!cpf || cpf.length < 11) return cpf;
    const numericCpf = cpf.replace(/\D/g, '');
    return `***.${numericCpf.substring(3, 6)}.${numericCpf.substring(6, 9)}-**`;
  };
  
  return (
    <div className="bg-background text-black flex flex-col h-screen">
      <div className="flex-1 overflow-y-auto">
        <div ref={receiptRef} className="bg-background p-6">
          <div className='pt-8 pb-4'>
            <NubankLogo />
          </div>
          <h1 className="text-3xl font-medium mb-1">Comprovante de transferência</h1>
          <p className="text-sm text-gray-500 mb-6">{format(formData.date, "dd MMM yyyy - HH:mm:ss", { locale: ptBR })}</p>

          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500">Valor</p>
                <p className="text-sm text-gray-900 font-medium">{formatCurrency(formData.amount)}</p>
            </div>
            <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500">Tipo de transferência</p>
                <p className="text-sm text-gray-900 font-medium">{formData.transferType}</p>
            </div>
          </div>
          
          <hr className="my-4 border-gray-200"/>

          <div className="space-y-4 my-6">
            <SectionTitle icon={Download} title="Destino" />
            <ReceiptField label="Nome" value={formData.receiverName} />
            <ReceiptField label="CPF" value={maskCpf(formData.receiverId)} />
            <ReceiptField label="Instituição" value={formData.receiverBank} />
            <ReceiptField label="Agência" value={formData.receiverAgency} />
            <ReceiptField label="Conta" value={formData.receiverAccount} />
            <ReceiptField label="Tipo de conta" value={formData.receiverAccountType} />
          </div>
        
          <hr className="my-4 border-gray-200"/>

           <div className="space-y-4 my-6">
              <SectionTitle icon={Download} title="Origem" />
              <ReceiptField label="Nome" value={formData.payerName} />
              <ReceiptField label="Instituição" value={`${formData.payerBank} - instituição de pagamento`} />
              <ReceiptField label="Agência" value="0001" />
              <ReceiptField label="Conta" value="1234567-8" />
          </div>
           <div className="bg-gray-100 p-4 text-sm text-gray-600 mt-6 rounded-lg">
                <p className='font-bold text-gray-800'>Nu Pagamentos S.A. - Instituição de Pagamento</p>
                <p>CNPJ 18.236.120/0001-58</p>
                <p className='font-bold mt-4 text-gray-800'>ID da transação:</p>
                <p className='break-all'>{transactionId}</p>
                <p className='mt-4'>Estamos aqui para ajudar se você tiver alguma dúvida.</p>
            </div>
        </div>
      </div>
      
      <div className="p-6 bg-background border-t border-border mt-auto space-y-2">
        <Button onClick={handleDownload} className="w-full h-12 bg-primary text-primary-foreground">
          <Download className="mr-2 h-4 w-4" />
          Baixar Comprovante
        </Button>
        <Button onClick={onDone} variant="ghost" className="w-full h-12">Concluir</Button>
      </div>
    </div>
  );
}
