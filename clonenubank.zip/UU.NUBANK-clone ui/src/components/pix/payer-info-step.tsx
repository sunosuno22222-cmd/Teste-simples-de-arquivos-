"use client";

import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { X } from "lucide-react";
import { pixFormSchema, PixFormData } from "./pix-form-schema";

const stepSchema = pixFormSchema.pick({
  payerName: true,
  payerId: true,
  payerBank: true,
});

interface PayerInfoStepProps {
  onNext: (data: Partial<PixFormData>) => void;
  defaultValues: Partial<PixFormData>;
  onClose: () => void;
}

export default function PayerInfoStep({ onNext, defaultValues, onClose }: PayerInfoStepProps) {
  const form = useForm<z.infer<typeof stepSchema>>({
    resolver: zodResolver(stepSchema),
    defaultValues: {
      payerName: defaultValues.payerName || "",
      payerId: defaultValues.payerId || "",
      payerBank: defaultValues.payerBank || "Nubank",
    },
  });

  const onSubmit = (data: z.infer<typeof stepSchema>) => {
    onNext(data);
  };
  
  // This step is now skipped, but we keep the logic just in case.
  // We can also trigger onSubmit immediately in a useEffect.
  React.useEffect(() => {
    // We have the data, so we can proceed to the next step.
    if (defaultValues.payerName && defaultValues.payerId) {
      onSubmit({
        payerName: defaultValues.payerName,
        payerId: defaultValues.payerId,
        payerBank: "Nubank"
      });
    }
  }, [defaultValues]);


  // Since this step will be skipped, we render a loading state
  // or a quick transition message while it auto-submits.
  return (
    <div className="flex h-full flex-col p-6 bg-primary text-primary-foreground items-center justify-center">
        <p>Carregando seus dados...</p>
    </div>
  );
}
