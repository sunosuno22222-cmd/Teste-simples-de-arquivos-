"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import ReceiverInfoStep from "./receiver-info-step";
import TransactionDetailsStep from "./transaction-details-step";
import ReceiptPage from "../pages/receipt-page";
import { PixFormData } from "./pix-form-schema";
import { UserProfile } from "@/app/page";
import PayerInfoStep from "./payer-info-step";


interface PixFlowProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  userProfile: UserProfile;
  onTransactionComplete?: (data: PixFormData) => void;
}

export default function PixFlow({ isOpen, onOpenChange, userProfile, onTransactionComplete }: PixFlowProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<PixFormData>>({
     date: new Date(),
     amount: 0,
     payerName: userProfile.name,
     payerId: userProfile.cpf,
     payerBank: 'Nu Pagamentos S.A.',
     transferType: "Pix",
  });

  const handleNext = (data: Partial<PixFormData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep((prev) => prev + 1);
  };

  const handleBack = () => {
    if (step === 1) {
        onOpenChange(false);
    } else if (step === 2) {
        // Skip back to close if we came from action shortcuts
        onOpenChange(false);
        handleReset();
    }
    else {
        setStep((prev) => prev - 1);
    }
  };
  
  const handleReset = (finalData?: PixFormData) => {
    if (finalData && onTransactionComplete) {
      onTransactionComplete(finalData);
    }
    setStep(1);
    setFormData({
        date: new Date(),
        amount: 0,
        payerName: userProfile.name,
        payerId: userProfile.cpf,
        payerBank: 'Nu Pagamentos S.A.',
        transferType: "Pix",
    });
    onOpenChange(false);
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <PayerInfoStep
            onNext={handleNext}
            defaultValues={formData}
            onClose={() => onOpenChange(false)}
          />
        );
      case 2:
        return (
          <ReceiverInfoStep
            onNext={handleNext}
            onBack={handleBack}
            defaultValues={formData}
          />
        );
      case 3:
        return (
          <TransactionDetailsStep
            onNext={handleNext}
            onBack={handleBack}
            defaultValues={formData}
          />
        );
      case 4:
        return <ReceiptPage formData={formData as PixFormData} onDone={() => handleReset(formData as PixFormData)} />;
      default:
        return null;
    }
  };
  
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      handleReset();
    }
    onOpenChange(open);
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="p-0 bg-background max-w-lg h-screen overflow-y-auto">
         <DialogHeader className="sr-only">
          <DialogTitle>Fluxo de Transferência Pix</DialogTitle>
          <DialogDescription>Siga os passos para criar um comprovante de transferência.</DialogDescription>
        </DialogHeader>
        {renderStep()}
      </DialogContent>
    </Dialog>
  );
}
