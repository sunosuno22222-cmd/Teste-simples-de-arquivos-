"use client";

import { z } from "zod";

export const pixFormSchema = z.object({
  payerName: z.string().min(1, "Nome do pagador é obrigatório"),
  payerId: z.string().min(1, "CPF ou Chave Pix é obrigatória"),
  payerBank: z.string().min(1, "Banco do pagador é obrigatório"),
  receiverName: z.string().min(1, "Nome do recebedor é obrigatório"),
  receiverId: z.string().min(1, "CPF ou Chave Pix é obrigatória"),
  receiverBank: z.string().min(1, "Banco do recebedor é obrigatório"),
  receiverAgency: z.string().min(1, "Agência é obrigatória"),
  receiverAccount: z.string().min(1, "Conta é obrigatória"),
  receiverAccountType: z.string().min(1, "Tipo de conta é obrigatório"),
  amount: z.number().min(1, "O valor deve ser maior que zero"),
  date: z.date(),
  transferType: z.enum(["Pix", "TED"], {
    required_error: "Você precisa selecionar um tipo de transferência.",
  }),
});

export type PixFormData = z.infer<typeof pixFormSchema>;
