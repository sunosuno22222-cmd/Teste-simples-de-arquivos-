"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { ArrowLeft } from "lucide-react";
import { pixFormSchema, PixFormData } from "./pix-form-schema";

const stepSchema = pixFormSchema.pick({
  receiverName: true,
  receiverId: true,
  receiverBank: true,
  receiverAgency: true,
  receiverAccount: true,
  receiverAccountType: true,
});

interface ReceiverInfoStepProps {
  onNext: (data: Partial<PixFormData>) => void;
  onBack: () => void;
  defaultValues: Partial<PixFormData>;
}

export default function ReceiverInfoStep({ onNext, onBack, defaultValues }: ReceiverInfoStepProps) {
  const form = useForm<z.infer<typeof stepSchema>>({
    resolver: zodResolver(stepSchema),
    defaultValues: {
      receiverName: defaultValues.receiverName || "",
      receiverId: defaultValues.receiverId || "",
      receiverBank: defaultValues.receiverBank || "",
      receiverAgency: defaultValues.receiverAgency || "",
      receiverAccount: defaultValues.receiverAccount || "",
      receiverAccountType: defaultValues.receiverAccountType || "Corrente",
    },
  });

  const onSubmit = (data: z.infer<typeof stepSchema>) => {
    onNext(data);
  };

    const handleCpfPixChange = (e: React.ChangeEvent<HTMLInputElement>, field: any) => {
    const value = e.target.value;
    const numericValue = value.replace(/\D/g, '');

    // Check if it's likely a CPF (only numbers)
    if (/^\d*$/.test(value.replace(/[.-]/g, ''))) {
        let formattedValue = numericValue;
        if (numericValue.length > 3) {
        formattedValue = numericValue.replace(/(\d{3})(\d)/, '$1.$2');
        }
        if (numericValue.length > 6) {
        formattedValue = formattedValue.replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
        }
        if (numericValue.length > 9) {
        formattedValue = formattedValue.replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4');
        }
        field.onChange(formattedValue.substring(0, 14));
    } else {
      // It's likely a pix key with letters
      field.onChange(value);
    }
  };


  return (
    <div className="flex h-full flex-col p-6 bg-primary text-primary-foreground">
      <button onClick={onBack} aria-label="Voltar" className="mb-8">
        <ArrowLeft className="h-6 w-6 text-primary-foreground" />
      </button>

      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-2">
            <h1 className="text-2xl font-medium leading-tight">Dados do Destinatário</h1>
            <p className="text-primary-foreground/70">Agora, as informações de quem vai receber.</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="receiverName"
              render={({ field }) => (
                <FormItem>
                  <Label>Nome do destinatário</Label>
                  <FormControl>
                    <Input placeholder="Nome Completo" {...field} className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="receiverId"
              render={({ field }) => (
                <FormItem>
                  <Label>CPF ou Chave Pix</Label>
                  <FormControl>
                    <Input 
                        placeholder="CPF ou chave aleatória" 
                        {...field} 
                        onChange={(e) => handleCpfPixChange(e, field)}
                        className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="receiverBank"
              render={({ field }) => (
                <FormItem>
                  <Label>Instituição do destinatário</Label>
                  <FormControl>
                    <Input placeholder="Ex: ITAÚ UNIBANCO S.A." {...field} className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="receiverAgency"
              render={({ field }) => (
                <FormItem>
                  <Label>Agência</Label>
                  <FormControl>
                    <Input placeholder="Ex: 0001" {...field} className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="receiverAccount"
              render={({ field }) => (
                <FormItem>
                  <Label>Conta com dígito</Label>
                  <FormControl>
                    <Input placeholder="Ex: 12345-6" {...field} className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="receiverAccountType"
              render={({ field }) => (
                <FormItem>
                  <Label>Tipo de conta</Label>
                  <FormControl>
                    <Input placeholder="Ex: Corrente" {...field} className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full bg-primary-foreground text-primary h-14 text-lg font-semibold">
              Continuar
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
