"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
  FormLabel,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ArrowLeft, Calendar as CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import React from "react";
import { pixFormSchema, PixFormData } from "./pix-form-schema";

const stepSchema = pixFormSchema.pick({
  amount: true,
  date: true,
  transferType: true,
});

interface TransactionDetailsStepProps {
  onNext: (data: Partial<PixFormData>) => void;
  onBack: () => void;
  defaultValues: Partial<PixFormData>;
}

export default function TransactionDetailsStep({ onNext, onBack, defaultValues }: TransactionDetailsStepProps) {
  const form = useForm<z.infer<typeof stepSchema>>({
    resolver: zodResolver(stepSchema),
    defaultValues: {
      amount: defaultValues.amount || 0,
      date: defaultValues.date || new Date(),
      transferType: defaultValues.transferType || "Pix",
    },
  });

  const onSubmit = (data: z.infer<typeof stepSchema>) => {
    onNext(data);
  };
    
  const formatCurrencyForInput = (value: number) => {
    if (isNaN(value)) return "0,00";
    const options = {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    };
    return (value / 100).toLocaleString('pt-BR', options);
  };
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numericValue = value.replace(/\D/g, '');
    if (numericValue) {
        const intValue = parseInt(numericValue, 10);
        form.setValue('amount', intValue);
    } else {
        form.setValue('amount', 0);
    }
  };


  return (
    <div className="flex h-full flex-col p-6 bg-primary text-primary-foreground">
      <button onClick={onBack} aria-label="Voltar" className="mb-8">
        <ArrowLeft className="h-6 w-6 text-primary-foreground" />
      </button>
      <div className="flex-1 flex flex-col justify-between">
        <div className="space-y-2">
            <h1 className="text-2xl font-medium leading-tight">Detalhes da Transação</h1>
            <p className="text-primary-foreground/70">Informe o valor e a data da transferência.</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <Label>Valor da Transferência</Label>
                  <FormControl>
                    <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-lg text-primary-foreground">R$</span>
                        <Input
                          type="text"
                          value={formatCurrencyForInput(field.value)}
                          onChange={handleAmountChange}
                          className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14 pl-10"
                        />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="transferType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Transferência</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-primary border-primary-foreground/50 text-lg text-primary-foreground placeholder:text-primary-foreground/70 h-14">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Pix">Pix</SelectItem>
                      <SelectItem value="TED">TED</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <Label>Data da Transação</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full h-14 justify-start text-left font-normal bg-primary border-primary-foreground/50 text-lg text-primary-foreground hover:bg-primary hover:text-primary-foreground",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {field.value ? (
                            format(field.value, "PPP", { locale: ptBR })
                          ) : (
                            <span>Escolha uma data</span>
                          )}
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) =>
                          date > new Date() || date < new Date("1900-01-01")
                        }
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full bg-primary-foreground text-primary h-14 text-lg font-semibold">
              Gerar Comprovante
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
