export const firebaseConfig = {
  "projectId": "studio-5606799460-32ccc",
  "appId": "1:979758876258:web:85836a9d390cb6afdff33b",
  "storageBucket": "studio-5606799460-32ccc.appspot.com",
  "apiKey": "AIzaSyDMEGCorVhMbtCdYCVdzaTwY94poyypRzQ",
  "authDomain": "studio-5606799460-32ccc.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "979758876258"
};
