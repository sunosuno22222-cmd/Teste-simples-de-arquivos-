"use client";

import { getStorage, ref, uploadString, getDownloadURL } from "firebase/storage";
import { useFirebase } from ".";

export function useFirebaseStorage() {
    const { firebaseApp } = useFirebase();
    return getStorage(firebaseApp);
}

export async function uploadDataUrl(path: string, dataUrl: string): Promise<string> {
    const storage = getStorage();
    const storageReference = ref(storage, path);
    await uploadString(storageReference, dataUrl, 'data_url');
    return getDownloadURL(storageReference);
}
